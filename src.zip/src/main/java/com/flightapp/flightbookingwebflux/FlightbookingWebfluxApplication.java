package com.flightapp.flightbookingwebflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightbookingWebfluxApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlightbookingWebfluxApplication.class, args);
    }

}
