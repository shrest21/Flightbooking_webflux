package com.flightapp.flightbookingwebflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightbookingWebfluxApplicationTests {

    @Test
    void contextLoads() {
        // This test is intentionally left empty.
        // Its purpose is to verify that the Spring Boot application context loads successfully.
    }
}
